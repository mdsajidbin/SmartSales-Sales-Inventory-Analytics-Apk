package com.example.model

data class Category(
    val id: String = "",
    val name: String = ""
)
